var fs = require('fs');

var errorLogger = function (err, req, res, next) {
    if (err) {
        fs.appendFile('ErrorLogger.txt', `${err.stack}\n`, function (err1) {
            if (err1) {
                console.log("logging error failed");
            }
        });
        res.status(err.statusCode ? err.statusCode : 500);
        res.json({ "message": err.message ? err.message : "Unknown error occured !!" })
    }
    next();
}

module.exports = errorLogger;
