const MongoClient = require('mongodb');

var connection = {};

connection.getConnection = function () {
    return MongoClient.connect("mongodb://localhost:27017/origa", {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }).then(function (database) {
        return database.db();
    })
}

module.exports = connection;
