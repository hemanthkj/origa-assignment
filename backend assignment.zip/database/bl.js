const dal = require('./dal');
const bl = {};

bl.getUsers = function () {
    return dal.getUsers();
}

bl.getOrders = function () {
    return dal.getOrders();
}

bl.updateNoOfOrders = function (userId, noOfOrders) {
    return dal.updateNoOfOrders(userId, noOfOrders);
}

module.exports = bl;