const connection = require('../shared/databaseConnection');
const dal = {};
var db;

dal.getUsers = async function () {
    if (!db) db = await connection.getConnection();
    return db.collection('User').find({}, { projection: { "_id": 0 } }).toArray();
}

dal.getOrders = async function () {
    if (!db) db = await connection.getConnection();
    return db.collection('Order').aggregate([
        {
            $group: {
                _id: "$userId",
                avg: { $avg: "$subtotal" },
                sum: { $sum: 1 }
            }
        },
        {
            $project: {
                "_id": 0,
                "userId": "$_id",
                "averageBillValue": { $floor: "$avg" },
                "noOfOrders": "$sum"
            }
        }
    ]).toArray();
}

dal.updateNoOfOrders = async function (userId, noOfOrders) {
    if (!db) db = await connection.getConnection();
    return db.collection('User').updateOne(
        { "userId": userId },
        { $set: { "noOfOrders": noOfOrders } })
}

module.exports = dal;