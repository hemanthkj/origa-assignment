var express = require('express');
var router = express.Router();
var bl = require('../database/bl');

router.get('/users/no-of-orders', async function (req, res, next) {
  try {
    const users = await bl.getUsers();
    const orders = await bl.getOrders();
    let result = orders.map((order) => {
      let name = users.filter((user) => { return order.userId === user.userId })[0]['name'];
      return {
        ...order,
        name: name
      }
    })
    res.send(result)
  } catch (err) {
    next(err)
  }
});

router.put('/users/no-of-orders', async function (req, res, next) {
  try {
    const orders = await bl.getOrders();
    const users = await bl.getUsers();
    for (let i = 0; i < users.length; i++) {
      const user = users[i];
      let noOfOrders;
      let ordersForUser = orders.filter((order) => { return order.userId === user.userId });
      if (ordersForUser[0]) noOfOrders = ordersForUser[0]['userId'];
      else noOfOrders = 0;
      await bl.updateNoOfOrders(user.userId, noOfOrders);
    }
    res.send({ success: true, message: "Successfully updated" })
  } catch (err) {
    next(err)
  }
})

module.exports = router;
