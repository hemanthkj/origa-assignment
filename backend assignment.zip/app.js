var express = require('express');
// var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
const cors = require('cors');
const errorLogger = require('./shared/errorLogger')


var app = express();

app.use(cors());
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use('/api', indexRouter);

app.use(errorLogger)

var port = process.argv[2];

if (port) {
  app.listen(port, () => {
    console.log(`Server started and listening at port ${port}`);
  })
} else {
  console.error("Port number is required");
  process.exit(1);
}

module.exports = app;
