import { Component, OnInit, ViewChild } from '@angular/core';
import { DashboardService } from './dashboard.service';

// Angular Material
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  pieChartData: object;
  pieChartOptions = {
    legend: false
  }
  users: object[];
  perc: number;
  userToShow: object;
  usersTableDataSource: any;
  usersTableColumns: string[] = ['sno', 'name', 'username', 'city', 'pincode', 'company'];

  constructor(
    private ds: DashboardService
  ) { }

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    this.ds.getUsers().subscribe((s) => {
      this.users = s;
      this.userToShow = this.users[0];
      this.drawPieChart(this.users);
      this.perc = Math.round((this.users.length / 100) * 100);
      this.populateUsersTable(this.users)
    }, (err) => {
      if (err.error.message) alert(err.error.message);
      else if (err.message) alert(err.message);
      else if (err.statusText) alert(err.statusText);
      else alert("Unknown Error");
    })
  }

  populateUsersTable(users) {
    let data = users.map((x) => {
      return {
        sno: x.id,
        name: x.name,
        username: x.username,
        city: x.address.city,
        pincode: x.address.zipcode,
        company: x.company.name,
      }
    });
    this.usersTableDataSource = new MatTableDataSource(data);
    this.usersTableDataSource.sort = this.sort;
  }

  drawPieChart(users) {
    let counts = {
      latneg: 0,
      latpos: 0,
      lngneg: 0,
      lngpos: 0
    };
    for (let i = 0; i < users.length; i++) {
      const user = users[i];
      let lat = parseFloat(user['address']['geo']['lat']);
      let lng = parseFloat(user['address']['geo']['lng']);
      if (lat < 0) {
        counts.latneg += 1;
      } else {
        counts.latpos += 1;
      }
      if (lng < 0) {
        counts.lngneg += 1;
      } else {
        counts.lngpos += 1;
      }
    }
    this.pieChartData = {
      labels: ['Lat(pos)', 'Lat(neg)', 'Lng(pos)', 'Lng(neg)'],
      datasets: [
        {
          data: [counts.latpos, counts.latneg, counts.lngpos, counts.lngneg],
          backgroundColor: [
            "#fc182c",
            "#34c0bd",
            "#fcbd49",
            "#969bb2"
          ],
          hoverBackgroundColor: [
            "#fc182c",
            "#34c0bd",
            "#fcbd49",
            "#969bb2"
          ]
        }]
    };
  }

}
